token = "1699547688:AAHjXPWPT1_u8l1SzI2F23Smj96B1l32BlA"
# DB_NAME="qbkisere"
# DB_PASS="e97nXcW-fCyonW3LvaJzWkvfbY4eui8a"
# DB_HOST="kashin.db.elephantsql.com"
# DB_PORT="5432"
# DB_USER="qbkisere"
# import psycopg2
# from config import *
# conn = psycopg2.connect(password=DB_PASS, port=DB_PORT, host=DB_HOST, database=DB_NAME, user=DB_USER)
